#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <LiquidCrystal_I2C.h>

// ============================================================
// PIN CONFIGURATION - 
// ============================================================
#define DHT_PIN        4
#define SSR_PIN        5
#define FAN_RELAY_PIN   32

#define LED_HIJAU      18
#define LED_MERAH      19
#define BUZZER_PIN     23

#define DHT_TYPE       DHT22

// ============================================================
// WiFi & MQTT CONFIGURATION
// ============================================================
const char* WIFI_SSID     = "Eping";
const char* WIFI_PASSWORD = "rahmayaniose23";
const char* MQTT_BROKER   = "broker.hivemq.com";
const int   MQTT_PORT     = 1883;
const char* MQTT_CLIENT   = "sikakao-esp32";

// MQTT Topics - sesuai Tabel 3.9
const char* TOPIC_SUHU           = "sikakao/suhu";
const char* TOPIC_KELEMBABAN     = "sikakao/kelembaban";
const char* TOPIC_OUTPUT_PID     = "sikakao/outputpid";
const char* TOPIC_STATUS_HEATER  = "sikakao/status/heater";
const char* TOPIC_STATUS_KIPAS   = "sikakao/status/kipas";
const char* TOPIC_SETPOINT       = "sikakao/setpoint";
const char* TOPIC_COMMAND        = "sikakao/command";
const char* TOPIC_STATUS         = "sikakao/status";

// ============================================================
// PID PARAMETERS 
// Kp=5, Ki=0.5, Kd=2
// ============================================================
float Kp = 2.0;
float Ki = 0;
float Kd = 0;

float setpointSuhu = 50.0;   // Setpoint default 50°C
float suhuAktual   = 0.0;
float kelembaban   = 0.0;

// PID Variables
float error_sekarang  = 0.0;
float error_sebelumnya = 0.0;
float integral_sum    = 0.0;
float output_pid      = 0.0;

// PID Output limits (0-100%)
const float PID_MIN = 0.0;
const float PID_MAX = 100.0;

// Integral Anti-Windup limit
const float INTEGRAL_MAX = 200.0;

// ============================================================
// TIME PROPORTIONING CONTROL - sesuai Flowchart PID (Gambar 3.6)
// Periode kontrol = 10 detik
// ============================================================
const unsigned long TPC_PERIOD = 10000; // 10 detik dalam ms
unsigned long tpc_start_time = 0;
unsigned long heater_on_time = 0;

// ============================================================
// SYSTEM STATE
// ============================================================
bool systemRunning = false;
bool heaterState = false;
bool kipasState = false;

String systemStatus = "BOOT";

// LCD VARIABLES
unsigned long lcdPreviousMillis = 0;
unsigned long stopDisplayMillis = 0;
const unsigned long LCD_INTERVAL = 3000; // Ganti halaman tiap 3 detik
bool lcdPage = false;
bool showStopMessage = false;
bool dryingFinished = false;

// Safety: Suhu maksimum 60°C
const float SUHU_MAX = 60.0;

// Threshold kelembaban selesai
const float RH_THRESHOLD = 40.0;

// Sampling interval (ms)
const unsigned long SAMPLE_INTERVAL = 2000;
unsigned long lastSampleTime = 0;

// MQTT publish interval (ms)
const unsigned long MQTT_INTERVAL = 3000;
unsigned long lastMqttTime = 0;

// ============================================================
// OBJECTS
// ============================================================
DHT dht(DHT_PIN, DHT_TYPE);
WiFiClient espClient;
PubSubClient mqtt(espClient);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ============================================================
// SETUP
// ============================================================
void setup() {

    Serial.begin(115200);
    Serial.println("\n=== SIKAKAO - Sistem Pengering Biji Kakao ===");

    // Status awal
    systemStatus = "BOOT";

    // Initialize pins
    pinMode(SSR_PIN, OUTPUT);
    digitalWrite(SSR_PIN, LOW);

    pinMode(FAN_RELAY_PIN, OUTPUT);
    digitalWrite(FAN_RELAY_PIN, LOW);

    // Kondisi awal
    digitalWrite(LED_HIJAU, LOW);
    digitalWrite(LED_MERAH, LOW);
    digitalWrite(BUZZER_PIN, LOW);

    // Initialize DHT22
    dht.begin();

    // Initialize LCD
    lcd.init();
    lcd.backlight();

    lcd.setCursor(0,0);
    lcd.print("SIKAKAO v1.0");

    lcd.setCursor(0,1);
    lcd.print("Initializing...");

    // Connect WiFi
    connectWiFi();

    // Setup MQTT
    mqtt.setServer(MQTT_BROKER, MQTT_PORT);
    mqtt.setCallback(mqttCallback);
    connectMQTT();

    // Initialize TPC timer
    tpc_start_time = millis();

    lcd.clear();
    lcd.print("SIKAKAO READY");
    // Indikator sistem siap
    for(int i = 0; i < 2; i++){

        digitalWrite(LED_HIJAU, HIGH);
        delay(150);
        digitalWrite(LED_HIJAU, LOW);
        delay(150);
    }
    // Bunyi sekali
    digitalWrite(BUZZER_PIN, HIGH);
    delay(200);
    digitalWrite(BUZZER_PIN, LOW);

    // Sistem siap
    digitalWrite(LED_HIJAU, HIGH);
    // Sistem siap menerima START
    systemStatus = "SIAP";
}
// ============================================================
// MAIN LOOP - sesuai Flowchart Alur Kerja Alat
// ============================================================
void loop() {
    // Maintain MQTT connection
    if (!mqtt.connected()) {
        connectMQTT();
    }
    mqtt.loop();
    
    unsigned long now = millis();
    
    // 1. Baca Sensor DHT22 (setiap SAMPLE_INTERVAL)
    if (now - lastSampleTime >= SAMPLE_INTERVAL) {
        lastSampleTime = now;
        readSensor();
        
        if (systemRunning) {
            // 2. Hitung Error (Setpoint - Suhu Aktual)
            // 3. Proses PID
            calculatePID();
            
            // 5. Cek Kelembaban - RH ≤ 40% = selesai
            if (kelembaban <= RH_THRESHOLD && kelembaban > 0) {
                dryingFinished = true;
                Serial.println("[SYSTEM] Kelembaban ≤ 40% - Pengeringan Selesai!");
                stopDrying();
            }
        }
        
        // Update LCD
        updateLCD();
    }
    
    // Time Proportioning Control untuk Heater
    if (systemRunning) {
        timeProportioningControl();
    }
    
    // Publish data ke MQTT
    if (now - lastMqttTime >= MQTT_INTERVAL) {
        lastMqttTime = now;
        publishData();
    }
}

// ============================================================
// SENSOR READING
// ============================================================
void readSensor() {
    float t = dht.readTemperature();
    float h = dht.readHumidity();
    
    if (!isnan(t) && !isnan(h)) {
        suhuAktual = t;
        kelembaban = h;
        Serial.printf("[SENSOR] Suhu: %.1f°C | RH: %.1f%%\n", suhuAktual, kelembaban);
    } else {
        Serial.println("[SENSOR] Error reading DHT22!");
        digitalWrite(LED_HIJAU, LOW);
        digitalWrite(LED_MERAH, HIGH);

    }
}

// ============================================================
// PID CALCULATION - sesuai Flowchart Kontrol PID 
// dan Skenario Sistem
// ============================================================
void calculatePID() {
    // Hitung Error
    error_sekarang = setpointSuhu - suhuAktual;
    
    // Komponen Proportional
    float P = Kp * error_sekarang;
    
    // Komponen Integral (dengan anti-windup)
    integral_sum += error_sekarang;
    if (integral_sum > INTEGRAL_MAX) integral_sum = INTEGRAL_MAX;
    if (integral_sum < -INTEGRAL_MAX) integral_sum = -INTEGRAL_MAX;
    float I = Ki * integral_sum;
    
    // Komponen Derivative
    float D = Kd * (error_sekarang - error_sebelumnya);
    
    // Output PID
    output_pid = P + I + D;
    
    // Pembatasan Output PID (0-100%)
    if (output_pid > PID_MAX) output_pid = PID_MAX;
    if (output_pid < PID_MIN) output_pid = PID_MIN;
    
    // Safety: matikan heater jika suhu > 60°C
    if (suhuAktual > SUHU_MAX) {

        output_pid = 0;

        digitalWrite(LED_HIJAU, LOW);
        digitalWrite(LED_MERAH, HIGH);

        digitalWrite(BUZZER_PIN, HIGH);

        Serial.println("[SAFETY] Suhu melebihi batas!");

    }
    else{

        digitalWrite(BUZZER_PIN, LOW);

    }
    
    // Simpan error sebelumnya
    error_sebelumnya = error_sekarang;
    
    // Konversi ke Time Proportioning
    heater_on_time = (unsigned long)(output_pid / 100.0 * TPC_PERIOD);
    
    Serial.printf("[PID] Error: %.1f | P: %.1f | I: %.1f | D: %.1f | Output: %.1f%% | ON: %lums\n",
                  error_sekarang, P, I, D, output_pid, heater_on_time);
}

// ============================================================
// TIME PROPORTIONING CONTROL 
// Periode = 10 detik
// ============================================================
void timeProportioningControl() {
    unsigned long elapsed = millis() - tpc_start_time;
    
    if (elapsed >= TPC_PERIOD) {
        // Reset siklus baru
        tpc_start_time = millis();
        elapsed = 0;
    }
    
    if (elapsed < heater_on_time) {
        // Heater ON
        if (!heaterState) {
            digitalWrite(SSR_PIN, HIGH);
            heaterState = true;
        }
    } else {
        // Heater OFF
        if (heaterState) {
            digitalWrite(SSR_PIN, LOW);
            heaterState = false;
        }
    }
}

// ============================================================
// STOP DRYING
// ============================================================
void stopDrying() {

    systemRunning = false;
    systemStatus = "STOP";

    // Tampilkan pesan STOP/SELESAI di LCD
    showStopMessage = true;
    stopDisplayMillis = millis();

    // Matikan kipas
    digitalWrite(FAN_RELAY_PIN, LOW);
    kipasState = false;

    // Matikan SSR
    digitalWrite(SSR_PIN, LOW);
    heaterState = false;

    // LED
    digitalWrite(LED_HIJAU, LOW);
    digitalWrite(LED_MERAH, HIGH);

    // Buzzer bunyi 3 kali
    for(int i = 0; i < 3; i++) {

        digitalWrite(BUZZER_PIN, HIGH);
        delay(200);

        digitalWrite(BUZZER_PIN, LOW);
        delay(200);

    }

    output_pid = 0;
    heater_on_time = 0;

    integral_sum = 0;
    error_sebelumnya = 0;

    Serial.println("[SYSTEM] Pengeringan dihentikan");
}
// ============================================================
// LCD UPDATE
// ============================================================
void updateLCD() {

    if (systemRunning) {
        if (millis() - lcdPreviousMillis >= LCD_INTERVAL) {
            lcdPreviousMillis = millis();
            lcdPage = !lcdPage;
        }
    } else {
        lcdPage = false;
    }

    static String lastLine1 = "";
    static String lastLine2 = "";

    String line1 = "";
    String line2 = "";

    if (showStopMessage) {
        line1 = "Pengeringan";

        if (dryingFinished)
            line2 = "Selesai";
        else
            line2 = "Dihentikan";

        if (millis() - stopDisplayMillis >= 5000) {
            showStopMessage = false;
        }
    }
    else

    // ==========================
    // BELUM START
    // ==========================
    if (!showStopMessage && !systemRunning) {

        line1 = "Suhu : " + String(suhuAktual,1) + (char)223 + "C";
        line2 = "RH   : " + String(kelembaban,1) + "%";

    }

    // ==========================
    // SUDAH START
    // ==========================
    else {

        if (!lcdPage) {

            line1 = "Pengeringan";
            line2 = "Sedang Berjalan";

        }
        else {

            line1 = "Suhu : " + String(suhuAktual,1) + (char)223 + "C";
            line2 = "RH   : " + String(kelembaban,1) + "%";

        }

    }

    while (line1.length() < 16) line1 += " ";
    while (line2.length() < 16) line2 += " ";

    if (line1 != lastLine1) {
        lcd.setCursor(0,0);
        lcd.print(line1);
        lastLine1 = line1;
    }

    if (line2 != lastLine2) {
        lcd.setCursor(0,1);
        lcd.print(line2);
        lastLine2 = line2;
    }
}
// ============================================================
// MQTT FUNCTIONS - sesuai Flowchart MQTT (Gambar 3.5)
// ============================================================
void connectWiFi() {
    Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 30) {
        delay(500);
        Serial.print(".");
        attempts++;
    }
    
    if (WiFi.status() == WL_CONNECTED) {
        Serial.printf("\n[WiFi] Connected! IP: %s\n", WiFi.localIP().toString().c_str());
    } else {
        Serial.println("\n[WiFi] Connection failed!");
    }
}

void connectMQTT() {
    while (!mqtt.connected()) {
        Serial.println("[MQTT] Connecting to broker...");
        if (mqtt.connect(MQTT_CLIENT)) {
            Serial.println("[MQTT] Connected!");
            // Subscribe ke topik setpoint dan command
            mqtt.subscribe(TOPIC_SETPOINT);
            mqtt.subscribe(TOPIC_COMMAND);
            Serial.println("[MQTT] Subscribed to control topics");
        } else {
            Serial.printf("[MQTT] Failed, rc=%d. Retrying in 5s...\n", mqtt.state()) ;
            delay(5000);
        }
    }
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
    String message = "";
    for (unsigned int i = 0; i < length; i++) {
        message += (char)payload[i];
    }
    
    Serial.printf("[MQTT] Received: %s = %s\n", topic, message.c_str());
    
    if (String(topic) == TOPIC_SETPOINT) {
        float newSetpoint = message.toFloat();
        if (newSetpoint >= 40.0 && newSetpoint <= 60.0) {
            setpointSuhu = newSetpoint;
            Serial.printf("[MQTT] Setpoint updated: %.1f°C\n", setpointSuhu);
        }
    }
    else if (String(topic) == TOPIC_COMMAND) {
    if (message == "START") {

        systemRunning = true;
        systemStatus = "RUNNING";

        digitalWrite(LED_HIJAU, HIGH);
        digitalWrite(LED_MERAH, LOW);

        // Nyalakan relay kipas
        digitalWrite(FAN_RELAY_PIN, HIGH);
        kipasState = true;

        // Reset PID
        heaterState = false;
        digitalWrite(SSR_PIN, LOW);

        integral_sum = 0;
        error_sebelumnya = 0;

        // Reset Time Proportioning Control
        tpc_start_time = millis();

        Serial.println("[MQTT] Command: START");
    }
        else if (message == "STOP") {

            dryingFinished = false;
          
            systemStatus = "STOP";

            stopDrying();

            Serial.println("[MQTT] Command: STOP");
        }
    }
}
void publishData() {
    if (!mqtt.connected()) return;
    
    char buf[16];
    
    dtostrf(suhuAktual, 4, 1, buf);
    mqtt.publish(TOPIC_SUHU, buf);
    
    dtostrf(kelembaban, 4, 1, buf);
    mqtt.publish(TOPIC_KELEMBABAN, buf);
    
    dtostrf(output_pid, 4, 1, buf);
    mqtt.publish(TOPIC_OUTPUT_PID, buf);
    
    mqtt.publish(TOPIC_STATUS_HEATER, heaterState ? "ON" : "OFF");
    mqtt.publish(TOPIC_STATUS_KIPAS, kipasState ? "ON" : "OFF");
    mqtt.publish(TOPIC_STATUS, systemStatus.c_str());
    
    Serial.println("[MQTT] Data published");
}
