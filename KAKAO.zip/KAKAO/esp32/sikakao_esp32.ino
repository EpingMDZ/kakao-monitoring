#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <LiquidCrystal_I2C.h>

// ============================================================
// PIN CONFIGURATION - 
// ============================================================
#define DHT_PIN        4
#define SSR_PIN        5

#define LED_HIJAU      18
#define LED_MERAH      19
#define BUZZER_PIN     23

#define DHT_TYPE       DHT22

// ============================================================
// WiFi & MQTT CONFIGURATION
// ============================================================
const char* WIFI_SSID     = "NAMA_WIFI_ANDA";
const char* WIFI_PASSWORD = "PASSWORD_WIFI_ANDA";
const char* MQTT_BROKER   = "broker.hivemq.com";
const int   MQTT_PORT     = 1883;
const char* MQTT_CLIENT   = "sikakao-esp32";

// MQTT Topics - sesuai Tabel 3.9
const char* TOPIC_SUHU           = "sikakao/suhu";
const char* TOPIC_KELEMBABAN     = "sikakao/kelembaban";
const char* TOPIC_OUTPUT_PID     = "sikakao/outputpid";
const char* TOPIC_STATUS_HEATER  = "sikakao/status/heater";
const char* TOPIC_STATUS_KIPAS   = "sikakao/status/kipas";
const char* TOPIC_SETPOINT       = "sikakao/setpoint";
const char* TOPIC_COMMAND        = "sikakao/command";
const char* TOPIC_STATUS         = "sikakao/status";

// ============================================================
// PID PARAMETERS - sesuai Skenario Sistem (Bab 3.14)
// Kp=5, Ki=0.5, Kd=2
// ============================================================
float Kp = 5.0;
float Ki = 0.5;
float Kd = 2.0;

float setpointSuhu = 45.0;   // Setpoint default 45°C
float suhuAktual   = 0.0;
float kelembaban   = 0.0;

// PID Variables
float error_sekarang  = 0.0;
float error_sebelumnya = 0.0;
float integral_sum    = 0.0;
float output_pid      = 0.0;

// PID Output limits (0-100%)
const float PID_MIN = 0.0;
const float PID_MAX = 100.0;

// Integral Anti-Windup limit
const float INTEGRAL_MAX = 200.0;

// ============================================================
// TIME PROPORTIONING CONTROL - sesuai Flowchart PID (Gambar 3.6)
// Periode kontrol = 10 detik
// ============================================================
const unsigned long TPC_PERIOD = 10000; // 10 detik dalam ms
unsigned long tpc_start_time = 0;
unsigned long heater_on_time = 0;

// ============================================================
// SYSTEM STATE
// ============================================================
bool systemRunning = false;
bool heaterState = false;
bool kipasState = false;

String systemStatus = "BOOT";
// Safety: Suhu maksimum 60°C
const float SUHU_MAX = 60.0;

// Threshold kelembaban selesai
const float RH_THRESHOLD = 40.0;

// Sampling interval (ms)
const unsigned long SAMPLE_INTERVAL = 2000;
unsigned long lastSampleTime = 0;

// MQTT publish interval (ms)
const unsigned long MQTT_INTERVAL = 3000;
unsigned long lastMqttTime = 0;

// ============================================================
// OBJECTS
// ============================================================
DHT dht(DHT_PIN, DHT_TYPE);
WiFiClient espClient;
PubSubClient mqtt(espClient);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ============================================================
// SETUP
// ============================================================
void setup() {

    Serial.begin(115200);
    Serial.println("\n=== SIKAKAO - Sistem Pengering Biji Kakao ===");

    // Status awal
    systemStatus = "BOOT";

    // Initialize pins
    pinMode(SSR_PIN, OUTPUT);
    digitalWrite(SSR_PIN, LOW);

    // Initialize DHT22
    dht.begin();

    // Initialize LCD
    lcd.init();
    lcd.backlight();

    lcd.setCursor(0,0);
    lcd.print("SIKAKAO v1.0");

    lcd.setCursor(0,1);
    lcd.print("Initializing...");

    // Connect WiFi
    connectWiFi();

    // Setup MQTT
    mqtt.setServer(MQTT_BROKER, MQTT_PORT);
    mqtt.setCallback(mqttCallback);
    connectMQTT();

    // Initialize TPC timer
    tpc_start_time = millis();

    lcd.clear();
    lcd.print("SIKAKAO READY");

    // Sistem siap menerima START
    systemStatus = "SIAP";
}
// ============================================================
// MAIN LOOP - sesuai Flowchart Alur Kerja Alat (Gambar 3.3)
// ============================================================
void loop() {
    // Maintain MQTT connection
    if (!mqtt.connected()) {
        connectMQTT();
    }
    mqtt.loop();
    
    unsigned long now = millis();
    
    // 1. Baca Sensor DHT22 (setiap SAMPLE_INTERVAL)
    if (now - lastSampleTime >= SAMPLE_INTERVAL) {
        lastSampleTime = now;
        readSensor();
        
        if (systemRunning) {
            // 2. Hitung Error (Setpoint - Suhu Aktual)
            // 3. Proses PID
            calculatePID();
            
            // 4. Kontrol Kipas
            controlFan();
            
            // 5. Cek Kelembaban - RH ≤ 40% = selesai
            if (kelembaban <= RH_THRESHOLD && kelembaban > 0) {
                Serial.println("[SYSTEM] Kelembaban ≤ 40% - Pengeringan Selesai!");
                stopDrying();
            }
        }
        
        // Update LCD
        updateLCD();
    }
    
    // Time Proportioning Control untuk Heater
    if (systemRunning) {
        timeProportioningControl();
    }
    
    // Publish data ke MQTT
    if (now - lastMqttTime >= MQTT_INTERVAL) {
        lastMqttTime = now;
        publishData();
    }
}

// ============================================================
// SENSOR READING
// ============================================================
void readSensor() {
    float t = dht.readTemperature();
    float h = dht.readHumidity();
    
    if (!isnan(t) && !isnan(h)) {
        suhuAktual = t;
        kelembaban = h;
        Serial.printf("[SENSOR] Suhu: %.1f°C | RH: %.1f%%\n", suhuAktual, kelembaban);
    } else {
        Serial.println("[SENSOR] Error reading DHT22!");
    }
}

// ============================================================
// PID CALCULATION - sesuai Flowchart Kontrol PID (Gambar 3.6)
// dan Skenario Sistem (3.12.1 - 3.12.4)
// ============================================================
void calculatePID() {
    // Hitung Error
    error_sekarang = setpointSuhu - suhuAktual;
    
    // Komponen Proportional
    float P = Kp * error_sekarang;
    
    // Komponen Integral (dengan anti-windup)
    integral_sum += error_sekarang;
    if (integral_sum > INTEGRAL_MAX) integral_sum = INTEGRAL_MAX;
    if (integral_sum < -INTEGRAL_MAX) integral_sum = -INTEGRAL_MAX;
    float I = Ki * integral_sum;
    
    // Komponen Derivative
    float D = Kd * (error_sekarang - error_sebelumnya);
    
    // Output PID
    output_pid = P + I + D;
    
    // Pembatasan Output PID (0-100%)
    if (output_pid > PID_MAX) output_pid = PID_MAX;
    if (output_pid < PID_MIN) output_pid = PID_MIN;
    
    // Safety: matikan heater jika suhu > 60°C
    if (suhuAktual > SUHU_MAX) {
        output_pid = 0;
        Serial.println("[SAFETY] Suhu melebihi batas! Heater OFF");
    }
    
    // Simpan error sebelumnya
    error_sebelumnya = error_sekarang;
    
    // Konversi ke Time Proportioning
    heater_on_time = (unsigned long)(output_pid / 100.0 * TPC_PERIOD);
    
    Serial.printf("[PID] Error: %.1f | P: %.1f | I: %.1f | D: %.1f | Output: %.1f%% | ON: %lums\n",
                  error_sekarang, P, I, D, output_pid, heater_on_time);
}

// ============================================================
// TIME PROPORTIONING CONTROL - sesuai Tabel 3.4, 3.5, 3.7
// Periode = 10 detik
// ============================================================
void timeProportioningControl() {
    unsigned long elapsed = millis() - tpc_start_time;
    
    if (elapsed >= TPC_PERIOD) {
        // Reset siklus baru
        tpc_start_time = millis();
        elapsed = 0;
    }
    
    if (elapsed < heater_on_time) {
        // Heater ON
        if (!heaterState) {
            digitalWrite(SSR_PIN, HIGH);
            heaterState = true;
        }
    } else {
        // Heater OFF
        if (heaterState) {
            digitalWrite(SSR_PIN, LOW);
            heaterState = false;
        }
    }
}

// ============================================================
// FAN CONTROL
// ============================================================
void controlFan() {
    if (systemRunning) {
        ledcWrite(0, 255);  // Full speed
        kipasState = true;
    } else {
        ledcWrite(0, 0);
        kipasState = false;
    }
}

// ============================================================
// STOP DRYING
// ============================================================
void stopDrying() {

    systemRunning = false;

    output_pid = 0;
    heater_on_time = 0;

    integral_sum = 0;
    error_sebelumnya = 0;

    digitalWrite(SSR_PIN, LOW);
    heaterState = false;

    kipasState = false;

    Serial.println("[SYSTEM] Pengeringan dihentikan");
}

// ============================================================
// LCD UPDATE
// ============================================================
// ============================================================
// LCD UPDATE
// ============================================================
void updateLCD() {

    lcd.clear();

    lcd.setCursor(0, 0);
    lcd.print("S:");
    lcd.print(suhuAktual, 1);
    lcd.print((char)223);
    lcd.print("C");

    lcd.setCursor(0, 1);
    lcd.print("RH:");
    lcd.print(kelembaban, 1);
    lcd.print("%");
}

// ============================================================
// MQTT FUNCTIONS - sesuai Flowchart MQTT (Gambar 3.5)
// ============================================================
void connectWiFi() {
    Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 30) {
        delay(500);
        Serial.print(".");
        attempts++;
    }
    
    if (WiFi.status() == WL_CONNECTED) {
        Serial.printf("\n[WiFi] Connected! IP: %s\n", WiFi.localIP().toString().c_str());
    } else {
        Serial.println("\n[WiFi] Connection failed!");
    }
}

void connectMQTT() {
    while (!mqtt.connected()) {
        Serial.println("[MQTT] Connecting to broker...");
        if (mqtt.connect(MQTT_CLIENT)) {
            Serial.println("[MQTT] Connected!");
            // Subscribe ke topik setpoint dan command
            mqtt.subscribe(TOPIC_SETPOINT);
            mqtt.subscribe(TOPIC_COMMAND);
            Serial.println("[MQTT] Subscribed to control topics");
        } else {
            Serial.printf("[MQTT] Failed, rc=%d. Retrying in 5s...\n", mqtt.state());
            delay(5000);
        }
    }
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
    String message = "";
    for (unsigned int i = 0; i < length; i++) {
        message += (char)payload[i];
    }
    
    Serial.printf("[MQTT] Received: %s = %s\n", topic, message.c_str());
    
    if (String(topic) == TOPIC_SETPOINT) {
        float newSetpoint = message.toFloat();
        if (newSetpoint >= 40.0 && newSetpoint <= 60.0) {
            setpointSuhu = newSetpoint;
            Serial.printf("[MQTT] Setpoint updated: %.1f°C\n", setpointSuhu);
        }
    }
    else if (String(topic) == TOPIC_COMMAND) {
        if (message == "START") {
            systemRunning = true;
            systemStatus = "RUNNING";
            heaterState = false;
            integral_sum = 0;
            error_sebelumnya = 0;

            Serial.println("[MQTT] Command: START");
        }
        else if (message == "STOP") {
            systemStatus = "STOP";
            stopDrying();
            Serial.println("[MQTT] Command: STOP");
        }
    }
}

void publishData() {
    if (!mqtt.connected()) return;
    
    char buf[16];
    
    dtostrf(suhuAktual, 4, 1, buf);
    mqtt.publish(TOPIC_SUHU, buf);
    
    dtostrf(kelembaban, 4, 1, buf);
    mqtt.publish(TOPIC_KELEMBABAN, buf);
    
    dtostrf(output_pid, 4, 1, buf);
    mqtt.publish(TOPIC_OUTPUT_PID, buf);
    
    mqtt.publish(TOPIC_STATUS_HEATER, heaterState ? "ON" : "OFF");
    mqtt.publish(TOPIC_STATUS_KIPAS, kipasState ? "ON" : "OFF");
    mqtt.publish(TOPIC_STATUS, systemStatus.c_str());
    
    Serial.println("[MQTT] Data published");
}
