#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <LiquidCrystal_I2C.h>

// ============================================================
// PIN CONFIGURATION
// ============================================================
#define DHT_PIN        4
#define SSR_PIN        5   // Mengontrol SSR 1 & SSR 2 (Paralel di Hardware)
#define FAN_RELAY_PIN  32  // Ke IN Pin Modul Relay 1 Channel Kipas

#define LED_HIJAU      18
#define LED_MERAH      19
#define BUZZER_PIN     23

#define DHT_TYPE       DHT22

// ============================================================
// WiFi & MQTT CONFIGURATION
// ============================================================
const char* WIFI_SSID     = "Eping";
const char* WIFI_PASSWORD = "rahmayaniose23";
const char* MQTT_BROKER   = "broker.hivemq.com";
const int   MQTT_PORT     = 1883;
const char* MQTT_CLIENT   = "sikakao-esp32";

const unsigned long WIFI_TIMEOUT_MS = 10000;

// MQTT Topics 
const char* TOPIC_SUHU           = "sikakao/suhu";
const char* TOPIC_KELEMBABAN     = "sikakao/kelembaban";
const char* TOPIC_OUTPUT_PID     = "sikakao/outputpid";
const char* TOPIC_STATUS_HEATER  = "sikakao/status/heater";
const char* TOPIC_STATUS_KIPAS   = "sikakao/status/kipas";
const char* TOPIC_SETPOINT       = "sikakao/setpoint";
const char* TOPIC_COMMAND        = "sikakao/command";
const char* TOPIC_STATUS         = "sikakao/status";

// ============================================================
// PID PARAMETERS 
// ============================================================
float Kp = 5.0;
float Ki = 0.1;
float Kd = 0.0;

float setpointSuhu = 50.0;   
float suhuAktual   = 0.0;
float kelembaban   = 0.0;

float error_sekarang   = 0.0;
float error_sebelumnya = 0.0;
float integral_sum     = 0.0;
float pid_p            = 0.0;
float pid_i            = 0.0;
float pid_d            = 0.0;
float output_pid       = 0.0;

const float PID_MIN = 0.0;
const float PID_MAX = 100.0;
const float INTEGRAL_MAX = 200.0;

// ============================================================
// TIME PROPORTIONING CONTROL (HEATER)
// ============================================================
const unsigned long TPC_PERIOD = 10000; 
unsigned long tpc_start_time = 0;
unsigned long heater_on_time = 0;

// ============================================================
// LOGIKA KIPAS INTERMITEN (10m ON / 1m OFF)
// ============================================================
bool kipasIstirahat  = false;        
unsigned long timerKipas = 0;        

const unsigned long DURASI_KIPAS_ON_MS  = 600000; // 10 Menit ON (600.000 ms)
const unsigned long DURASI_ISTIRAHAT_MS = 60000;  // 1 Menit OFF (60.000 ms)

// ============================================================
// SYSTEM STATE
// ============================================================
bool systemRunning = false;
bool heaterState   = false;
bool kipasState    = false;

String systemStatus = "BOOT";

// LCD VARIABLES
unsigned long lcdPreviousMillis = 0;
unsigned long stopDisplayMillis = 0;
const unsigned long LCD_INTERVAL = 3000; 
bool lcdPage          = false;
bool showStopMessage  = false;

const float SUHU_MAX     = 60.0;

const unsigned long SAMPLE_INTERVAL = 2000;
unsigned long lastSampleTime = 0;

const unsigned long MQTT_INTERVAL = 3000;
unsigned long lastMqttTime = 0;

// ============================================================
// OBJECTS
// ============================================================
DHT dht(DHT_PIN, DHT_TYPE);
WiFiClient espClient;
PubSubClient mqtt(espClient);
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Forward Declarations
void connectWiFi();
void connectMQTT();
void mqttCallback(char* topic, byte* payload, unsigned int length);
void readSensor();
void calculatePID();
void timeProportioningControl();
void controlActuators();
void stopDrying();
void updateLCD();
void publishData();

// ============================================================
// SETUP
// ============================================================
void setup() {
    Serial.begin(115200);
    Serial.println("\n=== SIKAKAO - ESP32 Single Pin Dual SSR & Intermittent Fan ===");

    systemStatus = "BOOT";

    pinMode(SSR_PIN, OUTPUT);
    digitalWrite(SSR_PIN, LOW);

    // Setup Relay Kipas (Relay 1 Channel)
    pinMode(FAN_RELAY_PIN, OUTPUT);
    digitalWrite(FAN_RELAY_PIN, LOW);

    pinMode(LED_HIJAU, OUTPUT);
    pinMode(LED_MERAH, OUTPUT);
    pinMode(BUZZER_PIN, OUTPUT);

    digitalWrite(LED_HIJAU, LOW);
    digitalWrite(LED_MERAH, LOW);
    digitalWrite(BUZZER_PIN, LOW);

    dht.begin();

    lcd.init();
    lcd.backlight();
    lcd.setCursor(0,0);
    lcd.print("SIKAKAO v2.1");
    lcd.setCursor(0,1);
    lcd.print("Init Hardware...");

    connectWiFi();

    mqtt.setServer(MQTT_BROKER, MQTT_PORT);
    mqtt.setCallback(mqttCallback);
    connectMQTT();

    tpc_start_time = millis();

    lcd.clear();
    lcd.print("SIKAKAO READY");

    digitalWrite(BUZZER_PIN, HIGH);
    delay(200);
    digitalWrite(BUZZER_PIN, LOW);

    digitalWrite(LED_HIJAU, HIGH);
    systemStatus = "SIAP";
}

// ============================================================
// MAIN LOOP
// ============================================================
void loop() {
    mqtt.loop();

    static unsigned long lastReconnect = 0;
    if (!mqtt.connected()) {
        if (millis() - lastReconnect >= 5000) {
            lastReconnect = millis();
            connectMQTT();
        }
    }
    
    unsigned long now = millis();
    
    // 1. Baca Sensor & Hitung PID
    if (now - lastSampleTime >= SAMPLE_INTERVAL) {
        lastSampleTime = now;
        readSensor();
        
        if (systemRunning) {
            calculatePID();
        }
        
        updateLCD();
    }
    
    // 2. Eksekusi Aktuator (Heater & Relay Kipas)
    if (systemRunning) {
        timeProportioningControl(); 
        controlActuators();          
    }
    
    // 3. Publish Data MQTT
    if (now - lastMqttTime >= MQTT_INTERVAL) {
        lastMqttTime = now;
        publishData();
    }
}

// ============================================================
// WIFI CONNECTION
// ============================================================
void connectWiFi() {
    Serial.printf("[WiFi] Memulai koneksi ke %s ...\n", WIFI_SSID);

    WiFi.setSleep(false);
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);
    WiFi.setTxPower(WIFI_POWER_15dBm);

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    unsigned long startAttempt = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - startAttempt < WIFI_TIMEOUT_MS) {
        Serial.print(".");
        delay(300);
    }

    if (WiFi.status() == WL_CONNECTED) {
        Serial.printf("\n[WiFi] Terhubung! IP: %s\n", WiFi.localIP().toString().c_str());
    } else {
        Serial.println("\n[WiFi] Retry koneksi...");
        WiFi.disconnect();
        WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
        delay(2000);
    }
}

// ============================================================
// SENSOR READING
// ============================================================
void readSensor() {
    float t = dht.readTemperature();
    float h = dht.readHumidity();
    
    if (!isnan(t) && !isnan(h)) {
        suhuAktual = t;
        kelembaban = h;

        if (systemRunning && suhuAktual <= SUHU_MAX) {
            digitalWrite(LED_HIJAU, HIGH);
            digitalWrite(LED_MERAH, LOW);
        }

        Serial.printf("[SENSOR] Suhu: %.1f°C | RH: %.1f%%\n", suhuAktual, kelembaban);
    } else {
        Serial.println("[SENSOR] Error reading DHT22!");
        digitalWrite(LED_HIJAU, LOW);
        digitalWrite(LED_MERAH, HIGH);
    }
}

// ============================================================
// PID & LOGIKA KIPAS INTERMITEN
// ============================================================
void calculatePID() {
    error_sekarang = setpointSuhu - suhuAktual;
    
    // LOGIKA HEATER (PID Aktif jika selisih < 5°C)
    if (error_sekarang > 5.0) {
        output_pid = 100.0; 
        integral_sum = 0;   
        pid_p = 0; pid_i = 0; pid_d = 0;
    } 
    else {
        pid_p = Kp * error_sekarang;
        
        integral_sum += error_sekarang;
        if (integral_sum > INTEGRAL_MAX)  integral_sum = INTEGRAL_MAX;
        if (integral_sum < -INTEGRAL_MAX) integral_sum = -INTEGRAL_MAX;
        pid_i = Ki * integral_sum;
        
        pid_d = Kd * (error_sekarang - error_sebelumnya);
        
        output_pid = pid_p + pid_i + pid_d;
    }
    
    if (output_pid > PID_MAX) output_pid = PID_MAX;
    if (output_pid < PID_MIN) output_pid = PID_MIN;
    
    // Safety Overheat
    if (suhuAktual > SUHU_MAX) {
        output_pid = 0;
        digitalWrite(LED_HIJAU, LOW);
        digitalWrite(LED_MERAH, HIGH);
        digitalWrite(BUZZER_PIN, HIGH);
        Serial.println("[SAFETY] Suhu melebihi batas 60°C!");
    } else {
        digitalWrite(BUZZER_PIN, LOW);
    }
    
    error_sebelumnya = error_sekarang;
    heater_on_time = (unsigned long)(output_pid / 100.0 * TPC_PERIOD);
    
    // ============================================================
    // LOGIKA KIPAS INTERMITEN (10 Menit ON -> 1 Menit OFF)
    // ============================================================
    unsigned long waktuSekarang = millis();

    if (!kipasIstirahat) {
        if (waktuSekarang - timerKipas >= DURASI_KIPAS_ON_MS) {
            kipasIstirahat = true;         // Matikan kipas (Istirahat 1 Menit)
            timerKipas     = waktuSekarang; 
            Serial.println("[KIPAS] 10 Menit ON Selesai -> Kipas OFF (1 Menit)");
        }
    } 
    else {
        if (waktuSekarang - timerKipas >= DURASI_ISTIRAHAT_MS) {
            kipasIstirahat = false;        // Nyalakan kipas kembali (10 Menit)
            timerKipas     = waktuSekarang; 
            Serial.println("[KIPAS] 1 Menit OFF Selesai -> Kipas ON (10 Menit)");
        }
    }
}

// ============================================================
// HEATER CONTROL (SSR)
// ============================================================
void timeProportioningControl() {
    unsigned long elapsed = millis() - tpc_start_time;
    
    if (elapsed >= TPC_PERIOD) {
        tpc_start_time = millis();
        elapsed = 0;
    }
    
    if (elapsed < heater_on_time) {
        if (!heaterState) {
            digitalWrite(SSR_PIN, HIGH);
            heaterState = true;
        }
    } else {
        if (heaterState) {
            digitalWrite(SSR_PIN, LOW);
            heaterState = false;
        }
    }
}

// ============================================================
// AKTUATOR: KONTROL RELAY KIPAS (1 CHANNEL)
// ============================================================
void controlActuators() {
    if (!kipasIstirahat) {
        // --- SAAT KIPAS HARUS ON ---
        if (!kipasState) {
            digitalWrite(FAN_RELAY_PIN, HIGH); // Relay ON
            kipasState = true;
        }
    } 
    else {
        // --- SAAT KIPAS HARUS OFF (ISTIRAHAT 1 MENIT) ---
        if (kipasState) {
            digitalWrite(FAN_RELAY_PIN, LOW);  // Relay OFF
            kipasState = false;
        }
    }
}

// ============================================================
// STOP DRYING
// ============================================================
void stopDrying() {
    systemRunning  = false;
    kipasIstirahat = false;
    systemStatus   = "STOP";

    showStopMessage   = true;
    stopDisplayMillis = millis();

    // Matikan Relay Kipas
    digitalWrite(FAN_RELAY_PIN, LOW);
    kipasState = false;

    digitalWrite(SSR_PIN, LOW);
    heaterState = false;

    digitalWrite(LED_HIJAU, LOW);
    digitalWrite(LED_MERAH, HIGH);

    for(int i = 0; i < 3; i++) {
        digitalWrite(BUZZER_PIN, HIGH);
        delay(200);
        digitalWrite(BUZZER_PIN, LOW);
        delay(200);
    }

    output_pid       = 0;
    heater_on_time   = 0;
    integral_sum     = 0;
    error_sebelumnya = 0;

    Serial.println("[SYSTEM] Pengeringan Berhenti Total");
}

// ============================================================
// LCD DISPLAY
// ============================================================
void updateLCD() {
    if (systemRunning) {
        if (millis() - lcdPreviousMillis >= LCD_INTERVAL) {
            lcdPreviousMillis = millis();
            lcdPage = !lcdPage;
        }
    } else {
        lcdPage = false;
    }

    static String lastLine1 = "";
    static String lastLine2 = "";

    String line1 = "";
    String line2 = "";

    if (showStopMessage) {
        line1 = "Pengeringan";
        line2 = "Dihentikan";

        if (millis() - stopDisplayMillis >= 5000) {
            showStopMessage = false;
        }
    }
    else if (!showStopMessage && !systemRunning) {
        line1 = "Suhu : " + String(suhuAktual,1) + (char)223 + "C";
        line2 = "RH   : " + String(kelembaban,1) + "%";
    }
    else {
        if (!lcdPage) {
            line1 = "Pengeringan";
            line2 = "Sedang Berjalan";
        }
        else {
            line1 = "Suhu : " + String(suhuAktual,1) + (char)223 + "C";
            line2 = "RH   : " + String(kelembaban,1) + "%";
        }
    }

    while (line1.length() < 16) line1 += " ";
    while (line2.length() < 16) line2 += " ";

    if (line1 != lastLine1) {
        lcd.setCursor(0,0);
        lcd.print(line1);
        lastLine1 = line1;
    }

    if (line2 != lastLine2) {
        lcd.setCursor(0,1);
        lcd.print(line2);
        lastLine2 = line2;
    }
}

// ============================================================
// MQTT FUNCTIONS
// ============================================================
void connectMQTT() {
    if (mqtt.connected()) return;
    Serial.println("[MQTT] Connecting...");

    if (mqtt.connect(MQTT_CLIENT)) {
        Serial.println("[MQTT] Connected");
        mqtt.subscribe(TOPIC_SETPOINT);
        mqtt.subscribe(TOPIC_COMMAND);
    } else {
        Serial.printf("[MQTT] Failed rc=%d\n", mqtt.state());
    }
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
    String message = "";
    for (unsigned int i = 0; i < length; i++) {
        message += (char)payload[i];
    }
    
    if (String(topic) == TOPIC_SETPOINT) {
        float newSetpoint = message.toFloat();
        if (newSetpoint >= 40.0 && newSetpoint <= 50.0) {
            setpointSuhu = newSetpoint;
        }
    }
    else if (String(topic) == TOPIC_COMMAND) {
        if (message == "START") {
            systemRunning   = true;
            kipasIstirahat  = false;        // Langsung ON 10 Menit pertama
            timerKipas      = millis();     // Reset timer kipas
            systemStatus    = "RUNNING";

            digitalWrite(LED_HIJAU, HIGH);
            digitalWrite(LED_MERAH, LOW);

            heaterState = false;
            digitalWrite(SSR_PIN, LOW);

            integral_sum     = 0;
            error_sebelumnya = 0;

            readSensor(); 
            tpc_start_time = millis();

            Serial.println("[MQTT] Command: START | Kipas ON Intermiten Dimulai");
        }
        else if (message == "STOP") {
            systemStatus   = "STOP";
            stopDrying();
            Serial.println("[MQTT] Command: STOP");
        }
    }
}

void publishData() {
    if (!mqtt.connected()) return;
    
    char buf[16];
    
    dtostrf(suhuAktual, 4, 1, buf);
    mqtt.publish(TOPIC_SUHU, buf);
    
    dtostrf(kelembaban, 4, 1, buf);
    mqtt.publish(TOPIC_KELEMBABAN, buf);
    
    dtostrf(output_pid, 4, 1, buf);
    mqtt.publish(TOPIC_OUTPUT_PID, buf);

    mqtt.publish(TOPIC_STATUS_HEATER, heaterState ? "ON" : "OFF");
    mqtt.publish(TOPIC_STATUS_KIPAS, kipasState ? "ON" : "OFF");
    mqtt.publish(TOPIC_STATUS, systemStatus.c_str());
}