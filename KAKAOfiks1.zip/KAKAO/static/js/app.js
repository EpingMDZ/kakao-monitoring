/* SIKAKAO - Common JavaScript Utilities */

// Auto-dismiss flash messages after 4.5 seconds
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        const msgs = document.querySelectorAll('.flash-msg');
        msgs.forEach(function(msg) { msg.remove(); });
    }, 4500);
});

const sidebar = document.querySelector(".sidebar");
const overlay = document.querySelector(".sidebar-overlay");
const toggle = document.getElementById("mobile-toggle");

toggle.addEventListener("click", () => {

    sidebar.classList.toggle("open");
    overlay.classList.toggle("active");

});

overlay.addEventListener("click", () => {

    sidebar.classList.remove("open");
    overlay.classList.remove("active");

});

/* ============================================================
   SWEETALERT UTILITIES
============================================================ */

// Popup sukses
function showSuccess(message) {

    Swal.fire({

        icon: "success",

        title: "Berhasil",

        text: message,

        confirmButtonColor: "#D2691E",

        confirmButtonText: "OK"

    });

}

// Popup error
function showError(message) {

    Swal.fire({

        icon: "error",

        title: "Terjadi Kesalahan",

        text: message,

        confirmButtonColor: "#D2691E",

        confirmButtonText: "OK"

    });

}

// Popup informasi
function showInfo(message) {

    Swal.fire({

        icon: "info",

        title: "Informasi",

        text: message,

        confirmButtonColor: "#D2691E",

        confirmButtonText: "OK"

    });

}

// Popup konfirmasi
function showConfirm(title, text) {

    return Swal.fire({

        icon: "warning",

        title: title,

        text: text,

        showCancelButton: true,

        confirmButtonColor: "#D2691E",

        cancelButtonColor: "#6c757d",

        confirmButtonText: "Ya",

        cancelButtonText: "Batal"

    });

}

/* ============================================================
   LOGOUT
============================================================ */

function confirmLogout() {

    Swal.fire({

        icon: "question",

        title: "Logout",

        text: "Apakah Anda yakin ingin keluar dari aplikasi?",

        showCancelButton: true,

        confirmButtonColor: "#D2691E",

        cancelButtonColor: "#6c757d",

        confirmButtonText: "Logout",

        cancelButtonText: "Batal"

    }).then((result) => {

        if(result.isConfirmed){

            window.location.href = "/logout";

        }

    });

}